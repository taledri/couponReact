package com.coupons.demo.clr;

import com.coupons.demo.Util.TablePrinter;
import com.coupons.demo.beans.Category;
import com.coupons.demo.beans.Company;
import com.coupons.demo.beans.Coupon;
import com.coupons.demo.beans.Customer;
import com.coupons.demo.configuration.LoginManager;
import com.coupons.demo.services.CompanyService;
import com.coupons.demo.services.CustomerService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.sql.Date;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Order(3)
@RequiredArgsConstructor
@Data
public class CustomerTest implements CommandLineRunner {
    private final LoginManager loginManager;
    private final CompanyService companyService;
    private final RestTemplate restTemplate;

    @Override
    public void run(String... args) throws Exception {
        Map<String, String> params = new HashMap<>();

        System.out.println("======LOGIN AS CUSTOMER SUCCESSFULLY======");
        CustomerService customerService = (CustomerService) loginManager.login(LoginManager.ClientType.CUSTOMER,"tal@gmail.com", "Tt1234");

        Coupon coupon = Coupon.builder()
                .companyId(2)
                .title(" spa")
                .description("choosing a massage from the list")
                .startDate(Date.valueOf("2022-06-01"))
                .endDate(Date.valueOf("2022-08-29"))
                .amount(50)
                .price(159.99)
                .image("beautifulWorld.img")
                .category(Category.VACATION)
                .build();
        companyService.addCoupon(coupon);

        System.out.println("======PURCHASE COUPON SUCCESSFULLY===");
        customerService.purchaseCoupon(coupon);
        String addURL = "http://localhost:8080/customer/purchaseCoupon";
        restTemplate.postForEntity(addURL, coupon, Coupon.class);

        System.out.println("====GET ALL CUSTOMER COUPONS BY CATEGORY===");
        customerService.getCustomerCouponByCategory(Category.VACATION);
        String customerCouponCategory = "http://localhost:8080/customer/getCustomerCouponByCategory{category}";
        params.put("category","VACATION");
        ResponseEntity<Coupon[]>customerCouponCategoryJason=restTemplate.getForEntity(customerCouponCategory,Coupon[].class,params);
        List<Coupon> getCustomerCouponByCategory= Arrays.asList(customerCouponCategoryJason.getBody());
        TablePrinter.print(getCustomerCouponByCategory);

        System.out.println("===GET ALL COUPONS CUSTOMER BUY UP TO SOME PRICE=== ");
        customerService.getCustomerCouponByMaxPrice(450);
        String customerCouponMaxPrice="http://localhost:8080/customer/getCustomerCouponByMaxPrice{maxPrice}";
        params.put("maxPrice","450");
        ResponseEntity<Coupon[]>customerCouponMAXpRICEJason=restTemplate.getForEntity(customerCouponMaxPrice,Coupon[].class,params);
        List<Coupon> getCustomerCouponByMaxPrice= Arrays.asList(customerCouponCategoryJason.getBody());
        TablePrinter.print(getCustomerCouponByMaxPrice);

        System.out.println("==GET ALL CUSTOMER DETAILS==");
        System.out.println(customerService.getCustomerDetails());
        String AllCustomerDetails="http://localhost:8080/students/getStudentByName/{name}";
        ResponseEntity<Customer[]> customerJason=restTemplate.getForEntity(AllCustomerDetails,Customer[].class);
        List<Customer> getCustomerDetails= Arrays.asList(customerJason.getBody());
        TablePrinter.print(getCustomerDetails);

    }
}
