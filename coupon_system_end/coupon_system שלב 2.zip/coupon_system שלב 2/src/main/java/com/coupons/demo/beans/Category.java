package com.coupons.demo.beans;

/**
 * e-num category string type that user enter in program
 */
public enum Category {
    ELECTRICITY,FOOD,PETS,TOURISM,OUTDOOR,VACATION,PHOTO,RESTAURANTS
}
