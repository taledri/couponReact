package com.coupons.demo.controllers;

import com.coupons.demo.beans.Category;
import com.coupons.demo.beans.Coupon;
import com.coupons.demo.exceptions.CompanySystemException;
import com.coupons.demo.exceptions.CouponSystemException;
import com.coupons.demo.exceptions.CustomerSystemException;
import com.coupons.demo.services.CompanyService;
import com.coupons.demo.services.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:8080", allowedHeaders = "*")
@RestController
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService customerService;

    /**
     * purchase coupon from database
     * @param coupon the coupon the customer wishes to buy
     * @return response entity with http status
     * @throws CouponSystemException
     */
    @PostMapping("/purchaseCoupon")
    public ResponseEntity<?> purchaseCoupon(@RequestBody Coupon coupon) throws CouponSystemException {
        customerService.purchaseCoupon(coupon);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    /**
     * customer coupon from database
     * @return response entity with http status and customer coupon
     * @throws CouponSystemException
     */
    @GetMapping("/getCustomerCoupons")
    public ResponseEntity<?> getCustomerCoupons() throws CouponSystemException {
        return new ResponseEntity<>(customerService.getCustomerCoupon(), HttpStatus.OK);
    }

    /**
     *customer coupon with same category from database
     * @param category coupon category
     * @return response entity with http status and customer coupon with same category
     * @throws CustomerSystemException if customer not exits
     * @throws CouponSystemException if customer does not have coupon with the wanted category
     */
    @GetMapping("/getCustomerCouponByCategory/{category}")
    public ResponseEntity<?> getCustomerCouponByCategory(@PathVariable Category category) throws CustomerSystemException, CouponSystemException {
        return new ResponseEntity<>(customerService.getCustomerCouponByCategory(category), HttpStatus.OK);
    }

    /**
     *customer coupon up to price from database
     * @param maxPrice max price we want to check
     * @return response entity with http status and customer coupon up to max price
     * @throws CouponSystemException if customer does not have coupon up to wanted price
     */
    @GetMapping("/getCustomerCouponByMaxPrice/{maxPrice}")
    public ResponseEntity<?> getCustomerCouponByMaxPrice(@PathVariable double maxPrice) throws CouponSystemException {
        return new ResponseEntity<>(customerService.getCustomerCouponByMaxPrice(maxPrice), HttpStatus.OK);
    }

    /**
     *customer details
     * @return esponse entity with http status and customer details
     */
    @GetMapping("/getCustomerDetails")
    public ResponseEntity<?> getCustomerDetails()   {
        return new ResponseEntity<>(customerService.getCustomerDetails(), HttpStatus.OK);
    }

}
